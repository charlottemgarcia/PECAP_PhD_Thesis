function ECAP_Struct = run_loudness_and_ecap(param)

% ECAP_Struct = run_loudness_and_ecap(param)
%   a function that passes parameters to a stimulation structure
%   (stim_struct) that is then passed to the loudness scaling GUI
%
%   Inputs:
%       - param:        structure containing ECAP recording parameters
%   Outputs:
%       - ECAP_Struct:  structure containing ECAPs and their loudness
%                       rankings as a result of the loudness-scaling GUI
% 
% Required Software:
%   [level_recorded, recording_EL, signal_recorded, ECAP_Struct, ...
%       responses] = loudness_evaluation_and_record(handle_BEDCS, ...
%       signal_struct, param)
%   [level_recorded, recording_EL, signal_recorded, ECAP_Struct, ...
%       responses] = loudness_evaluation_and_record_TP(handle_BEDCS, ...
%       signal_struct, param)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Developed by Francois Guerit                                            %
% Ammended by Charlotte Garcia, May 2021                                  %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create stimu struct

stim_struct.ELrec = param.rec_EL;     % recording electode
stim_struct.Tp = param.phase_duration_us;
stim_struct.Tdel = param.masker_probe_delay_us;
stim_struct.level = [param.level_start_masker param.level_start_probe];
stim_struct.Imasker = param.level_start_masker;
stim_struct.Iprobe = param.level_start_probe;
stim_struct.ELmasker = param.electrode_masker;
stim_struct.ELprobe = param.electrode_probe;
if min(param.condition == 'TP')
    stim_struct.alpha = param.start_alpha;
end

%% create handles

if param.debug
    handle_BEDCS = [];
else
    handle_BEDCS = actxserver('BEDCS2.CBEDCSApp');
    handle_BEDCS.Online = 1;
    handle_BEDCS.Visible = 0;
    
    
    [current_path, ~, ~] = fileparts(mfilename('fullpath'));
    full_filename = [current_path filesep param.exp_file];
    
    % Load the file if not already done
    if ~strcmp(handle_BEDCS.ExpFileName, full_filename)
        handle_BEDCS.LoadExpFile(full_filename)
    end
    
    % Update the stimulus properties
    fields = fieldnames(stim_struct);
    for i = 1:length(fields)
        if ~strcmp(fields{i}, 'level')
            handle_BEDCS.Let_ControlVarVal(fields{i},...
                stim_struct.(fields{i}))
        end
    end
    
    % To allow stimulation above 24 uA in BEDCS verson 1.8.321
    % (this is unecessary in version 1.8.337)
    % this turns off the OLS error 
    handle_BEDCS.ULevelMode = 1;
    
end

%% call loudness gui

if min(param.condition == 'TP')
    [level_recorded, recording_EL, signal_recorded, ECAP_Struct, responses] = ...
        loudness_evaluation_and_record_TP(handle_BEDCS, stim_struct, param);
else
    [level_recorded, recording_EL, signal_recorded, ECAP_Struct, responses] = ...
        loudness_evaluation_and_record(handle_BEDCS, stim_struct, param);
end
