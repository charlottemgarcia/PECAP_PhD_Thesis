function plot_SOEs(PECAP_Data, param)

% PECAP_Data = plot_SOEs(PECAP_Data, param)
%   takes an input of the PECAP_Data structure that is the output from
%   plot_PECAP() and plots the traditional spread of excitation (SOE)
%   functions (Cohen et al 2003) in line graphs. This is the ECAP amplitude
%   for each masker location with the probe location fixed.
%
%   Inputs:
%       - PECAP_Data:   structure containing monopolar PECAP data that is
%                       the output of run_PECAP()
%       - param:        structure containing recording parameters that is
%                       required for visualisation within the plot
%   Outputs:
%       - n/a
%
% Required Software:
%   PECAP_Data = run_PECAP(param);
%   PECAP_Data = plot_PECAP(PECAP_Data, param);
%   [a, details, mask] = ecap_amplitude(v, t, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 05 Oct 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initiate variables and matrices
minelec = min(param.electrodes);
maxelec = max(param.electrodes);
M = zeros(length(param.electrodes),length(param.electrodes));

% create M matrix
for ii = 1:length(PECAP_Data)
    M(PECAP_Data(ii).Probe - minelec + 1, ...
        PECAP_Data(ii).Masker - minelec + 1) = PECAP_Data(ii).Amp_uV;
end

% definte plot limits
ylims = [0 round(max(max(M))+max(max(M))*0.10,0)];

% save datetime string
datetimestr = datestr(datetime);

% plot SOEs
for ii = 1:4
    figure;
    for jj = 1:4
        subplot(2,2,jj); hold on;
        if jj+4*(ii-1) < minelec || jj+4*(ii-1) > maxelec
            text(3,ylims(2)/2,['No SOE for Electrode' ...
                num2str(jj+4*(ii-1))]);
        else
            plot(param.electrodes,M(jj+4*(ii-1)-minelec+1,:),'k-*');
            scatter(jj+4*(ii-1), ...
                M(jj+4*(ii-1)-minelec+1,jj+4*(ii-1)-minelec+1),'bo');
        end
        ylim(ylims); yticks(0:round(ylims(2)/5,0):ylims(2)); 
        ylabel('ECAP Amplitude (\muV)')
        xlim([0.5 16.5]); xticks(1:16); xlabel('Masker Electrode')
        title(['SOE Curve for Electrode ' num2str(jj+4*(ii-1))]);
    end
    savefig(['data/figs/Subj' param.ID '_cond' param.condition ...
    '_SOEs_' num2str(1+4*(ii-1)) 'to' num2str(4+4*(ii-1)) '_' date '_' datetimestr(13:14) '-' ...
    datetimestr(16:17) '-', datetimestr(19:20)]);
end
        