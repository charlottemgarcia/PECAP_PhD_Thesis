function plot_ABCD_frames_AB(signal_all, param)

% plot_ABCD_frames_AB(signal_all, param)
%   takes the signals recorded from BEDCS which are the output from
%   run_BEDCS_and_get_ECAP() as well as other recording parameters and
%   plots all 4 frames of the A, B, C, and D recordings that are required
%   for the forward-masking artefact-cancellation technique for recording
%   ECAPs and when combined as A - (B - C) - D result in an ECAP response
%
%   Inputs:
%       - signal_all:   structure that contains A, B, C, and D frames from
%                       recording an ECAP and is the output from
%                       run_BEDCS_and_get_ECAP()
%       - param:        structure with recording parameters that is passed
%                       to run_BEDCS_and_get_ECAP() and is required for 
%                       visualization within the plots 
%   Outputs: n/a
%
% Required Software: 
%   [signal_all, time_vector_ms] = run_BEDCS_and_get_ECAP(h,param)
%   [a, details, mask] = ecap_amplitude(v, t, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, May 2021                                              %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Plot A, B, C, and D frames of the ECAP recording
% open figure of interest
figure(10);

% generate time vector and ECAP waveform from subtraction
time_vector_ms = signal_all.time;
ECAP = signal_all.A - (signal_all.B - signal_all.C) - signal_all.D;

% set y-lims
yRange = [min([signal_all.A signal_all.B signal_all.C signal_all.D])-0.1 ...
    max([signal_all.A signal_all.B signal_all.C signal_all.D])+0.1];
yRange_ECAP = [min(ECAP)-0.1 max(ECAP)+0.1];

% plot C (masker only)
subplot(2,3,1); plot(time_vector_ms, signal_all.C); title('C: Masker Only');
xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
ylim(yRange); ylabel('Voltage (mV)'); 

% plot B (masker + probe)
subplot(2,3,2); plot(time_vector_ms, signal_all.B); title('B: Masker + Probe');
xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
ylim(yRange); ylabel('Voltage (mV)');

% plot A (probe only)
subplot(2,3,4); plot(time_vector_ms, signal_all.A); title('A: Probe Only')
xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
ylim(yRange); ylabel('Voltage (mV)');

% plot B (system signature)
subplot(2,3,5); plot(time_vector_ms, signal_all.D); title('D: Noise')
xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
ylim(yRange); ylabel('Voltage (mV)');

% plot all frames
subplot(2,3,3); hold off; plot(time_vector_ms, signal_all.A); hold on;
plot(time_vector_ms, signal_all.B); plot(time_vector_ms, signal_all.C); 
plot(time_vector_ms, signal_all.D); title('All Frames'); 
legend({'A','B','C','D'},'location','best'); legend boxoff;
xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
ylim(yRange); ylabel('Voltage (mV)');

% plot ECAP & amplitude
subplot(2,3,6); hold off; plot(time_vector_ms, ECAP); hold on;
[a, details] = ecap_amplitude(ECAP,time_vector_ms,param);
xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
ylim(yRange_ECAP); ylabel('Voltage (mV)'); title('ECAP Waveform')
r = scatter(details(:,1),details(:,2),'ro');
legend(r,{['Amp = ' num2str(a) ' mV']},'location','best'); legend boxoff
